#Concatenating team jersey and nation jersey
players_19 <- unite(players_19, 'jersey_numbers', team_jersey_number, nation_jersey_number, sep =',')
View(players_19)

#Concatenating team position and nation position
players_19 <- unite(players_19, 'club_and_nation_positions', team_position, nation_position, sep =',')
View(players_19)