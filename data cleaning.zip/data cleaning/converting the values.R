#Changing height from centimeter to feet

players_19 <- players_19 %>% 
  mutate(height_feet = height_cm / 30.48, sep ="ft")
print(players_19)
View(players_19)

#Viewing the updated height

players_19 %>% 
  select(height_feet)

#Changing weight from kilograms to pounds

players_19 <- players_19 %>% 
  mutate(weight_ibs = weight_kg * 2.20462, sep ="ibs")
print(players_19)
View(players_19)

#Viewing the updated weight

players_19 %>% 
  select(weight_ibs)